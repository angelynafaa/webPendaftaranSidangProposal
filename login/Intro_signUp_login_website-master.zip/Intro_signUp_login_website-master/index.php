<html>
	<head>
		<title>
		Online course portal
		</title>
	</head>
		<body background='bg.jpg' topmargin=10 leftmargin=10>
		<center>
         <img src=am.jpg weight=100 height=100>
		<font face='Bernard MT Condensed' size=7 color=RED face='#8A2BE2'><b><i><u>ONLINE COURSE PORTAL</u></i></b></font><br><hr>
		<table width=90%>
		<tr bgcolor=pink><td><center><a href=index.php>HOME</a></center></td><td><center><a href=about.php>About Us</a></center></td><td><center><a href=login.php>Login</a></center></td><td><center><a href=sign.php>Sign Up</a></center></td></tr>
		<tr><td colspan=2 width=50%>
		<font size=5><br>
	   Online course portal for a  campus is a web based
	   application which can be used for a campus.<br><br>
	   In the present computerized world, one can built up
	   his career through online courses having
	   beneficial in time and achieving his goal
	   in earning the biggest and most
	   important investment in life.<br>
	   The system stores information about
	   all the latest courses and the registered users.<br><br>
	   This allows registered users of the system
	   to join a course available in the site
	   and access the materials published for the course.<br>
	   There will be a course portal home page
	   which contain a registration link as well as login
</td>
<td colspan=2 width=50%><img src=welcome1.jpg weight=250 height=250 align=right></td></tr></table>
</font>
</pre>
<br><br><br><br><br><br><hr>
<center><a href="about.php">About us</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="about.php">Contact Us</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href>Site map</a></center>



			</form>
			</body>
</html>
