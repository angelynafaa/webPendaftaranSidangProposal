<html>
	<head>
		<title>
		Online course portal
		</title>
		<!-- <link rel="stylesheet" href="css1.css"> -->
		<!-- <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet"> -->
	</head>

		<body background='bg.jpg' topmargin=10 leftmargin=10 ><center>
         <img src=am.jpg weight=100 height=100>
		<font face='Bernard MT Condensed' size=7 color=RED face='#8A2BE2'><b><i><u>ONLINE COURSE PORTAL</u></i></b></font><br><hr>


		<table width=90%>
		<tr bgcolor=pink><td><center><a href=index.php>HOME</a></center></td><td><center><a href=about.php>About Us</a></center></td><td><center><a href=login.php>Login</a></center></td><td><center><a href=sign.php>Sign Up</a></center></td></tr>
		<tr><td colspan=2 width=50%>
		<font size=5><br>
			Online course portal for a  campus is a web based
 	   application which can be used for a campus.<br><br>
 	   In the present computerized world, one can built up
 	   his career through online courses having
 	   beneficial in time and achieving his goal
 	   in earning the biggest and most
 	   important investment in life.<br>
 	   The system stores information about
 	   all the latest courses and the registered users.<br><br>
 	   This allows registered users of the system
 	   to join a course available in the site
 	   and access the materials published for the course.<br>
 	   There will be a course portal home page
 	   which contain a registration link as well as login
</td><td colspan=2 width=50%>
<center>
<table>
<form name=frm1 action=login1.php>




  <tr><td colspan=2><center><img src=img.jpg weight=200 height=200></center></td></tr>
  <br><br><br>
  	<tr><td>Name : </td><td>ARYAN MITTAL</td></tr>
  	<tr><td>Contact No : </td><td>7390913001</td></tr>
    <tr><td>Email Id : </td><td>rocking.am12459@gmail.com</td></tr>
    <tr><td>College : </td><td>MNNIT Allahabad</td></tr>
  </table>
  </form>
  </center>
  </td></tr></table>
  </font>
  </pre>
  <br><br><br><br><br><br><hr>
  <center><a href>About us</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href>Contact Us</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href>Site map</a></center>



  			</form>
  			</body>
  </html>
