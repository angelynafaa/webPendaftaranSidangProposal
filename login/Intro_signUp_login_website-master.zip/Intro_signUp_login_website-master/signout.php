<?php
session_start();
session_destroy();
echo "U ARE LOGOUT PLEASE LOGIN AGAIN  : <br> <a href='login.php'>LOGIN HERE</a>";

?>
